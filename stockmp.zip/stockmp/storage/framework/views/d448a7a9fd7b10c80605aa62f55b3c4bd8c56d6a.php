<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
		 <div class="row">
                    <div class="col-lg-6 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <div id="ambarchart1"></div>
                            </div>
                        </div>
                    </div>
                </div>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


	<script type="text/javascript">
	
/*--------------  bar chart 08 amchart start ------------*/
if ($('#ambarchart1').length) {
    var chart = AmCharts.makeChart("ambarchart1", {
        "theme": "light",
        "type": "serial",
        "balloon": {
            "adjustBorderColor": false,
            "horizontalPadding": 10,
            "verticalPadding": 4,
            "color": "#fff"
        },
        "dataProvider": [{
            "country": "USA",
            "year2004": 3.5,
            "year2005": 4.2,
            "color": "#bfbffd",
            "color2": "#7474F0"
        }, {
            "country": "UK",
            "year2004": 1.7,
            "year2005": 3.1,
            "color": "#bfbffd",
            "color2": "#7474F0"
        }, {
            "country": "Canada",
            "year2004": 2.8,
            "year2005": 2.9,
            "color": "#bfbffd",
            "color2": "#7474F0"
        }, {
            "country": "Japan",
            "year2004": 2.6,
            "year2005": 2.3,
            "color": "#bfbffd",
            "color2": "#7474F0"
        }, {
            "country": "France",
            "year2004": 1.4,
            "year2005": 2.1,
            "color": "#bfbffd",
            "color2": "#7474F0"
        }, {
            "country": "Brazil",
            "year2004": 2.6,
            "year2005": 4.9,
            "color": "#bfbffd",
            "color2": "#7474F0"
        }],
        "valueAxes": [{
            "unit": "%",
            "position": "left",
        }],
        "startDuration": 1,
        "graphs": [{
            "balloonText": "GDP grow in [[category]] (2017): <b>[[value]]</b>",
            "fillAlphas": 0.9,
            "fillColorsField": "color",
            "lineAlpha": 0.2,
            "title": "2017",
            "type": "column",
            "valueField": "year2004"
        }, {
            "balloonText": "GDP grow in [[category]] (2018): <b>[[value]]</b>",
            "fillAlphas": 0.9,
            "fillColorsField": "color2",
            "lineAlpha": 0.2,
            "title": "2018",
            "type": "column",
            "clustered": false,
            "columnWidth": 0.5,
            "valueField": "year2005"
        }],
        "plotAreaFillAlphas": 0.1,
        "categoryField": "country",
        "categoryAxis": {
            "gridPosition": "start"
        },
        "export": {
            "enabled": false
        }

    });
}

/*--------------  bar chart 08 amchart END ------------*/

	</script>
</body>
</html>