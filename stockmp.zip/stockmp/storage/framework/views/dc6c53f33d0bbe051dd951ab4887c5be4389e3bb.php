<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <!-- Scripts -->
        <script src="<?php echo e(url('public/js/app.js')); ?>" defer></script>
        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
        <!-- Styles -->
        <link href="<?php echo e(url('public/css/app.css')); ?>" rel="stylesheet">
    </head>
    <body>

        <div class="container">


            <div class="row" >
                <div class="col-sm-10">
                <form action="<?php echo e(url('/store')); ?>" method="post"  style="margin-top:20px;">
                 <?php echo csrf_field(); ?>
                     <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Company name')); ?></label>

                            <div class="col-md-6">
                    <input type="text" class="form-control" name="comp">
                        </div>
                    </div>
                     <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('open value')); ?></label>

                            <div class="col-md-6">
                    <input type="text" class="form-control" name="open">
                </div>
            </div> 
            <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('close value')); ?></label>
                            <div class="col-md-6">
                    <input type="text" class="form-control" name="close">
                </div>
            </div>
            <div class="form-group row">

                 <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('')); ?></label>
                <div class="col-md-6">
                    <input type="submit" class="btn btn-primary" name="submit" value="submit">
                </div>
            </div>

                </form>
            </div>
            </div>
            
        </div>

        
    </body>
</html>